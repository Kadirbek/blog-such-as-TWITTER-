package servlets;

import classes.Post;
import classes.User;
import utils.DBUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet("/home")
public class HomeServlet extends HttpServlet {

    DBUtil dbUtil;

    public HomeServlet() {
        dbUtil = new DBUtil();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        String loadPage;
        String page = request.getParameter("page");

        if (user != null) {

            loadPage = "home";

            if (page != null) {
                if (page.equals("editPost")) {
                    loadPage = "editPost";
                } else if (page.equals("deletePost")) {
                    loadPage = "deletePost";
                } else {
                    loadPage = "home";
                    List<Post> posts = dbUtil.getAllPosts();
                    request.setAttribute("posts", posts);
                }
            }
        } else {

            loadPage = "auth";

            if (page != null) {
                if (page.equals("auth")) {
                    loadPage = "auth";
                } else if (page.equals("reg")) {
                    loadPage = "reg";
                }
            }
        }

        request.getRequestDispatcher(loadPage + ".jsp").forward(request, response);
    }
}
