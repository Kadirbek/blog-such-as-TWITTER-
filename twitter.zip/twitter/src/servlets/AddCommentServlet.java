package servlets;

import utils.DBUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/addComment")
public class AddCommentServlet extends HttpServlet {

    DBUtil dbUtil;

    public AddCommentServlet() {
        dbUtil = new DBUtil();
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        Long blogId = Long.parseLong(req.getParameter("blogId"));
        Long userId = Long.parseLong(req.getParameter("userId"));
        String content = req.getParameter("content");

        boolean isSuccessfullyAdded = dbUtil.addComment(userId, blogId, content);
        if (isSuccessfullyAdded) {
            resp.sendRedirect("/home?page=home");
        } else {
            resp.sendRedirect("/home?page=home&error=1");
        }
    }
}
