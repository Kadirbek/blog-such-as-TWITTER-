package servlets;

import classes.User;
import utils.DBUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/reg")
public class RegServlet extends HttpServlet {

    DBUtil dbUtil;

    public RegServlet() {
        dbUtil = new DBUtil();
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String name = req.getParameter("name");
        String email = req.getParameter("email");
        String password = req.getParameter("password");

        boolean isSuccessfullyAdded = dbUtil.addUser(name, email, password);
        if (isSuccessfullyAdded) {
            resp.sendRedirect("/home?page=auth");
        } else {
            resp.sendRedirect("/home?page=reg&error=1");
        }
    }
}
