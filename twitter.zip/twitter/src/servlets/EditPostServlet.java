package servlets;

import classes.Post;
import utils.DBUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/editPost")
public class EditPostServlet extends HttpServlet {

    DBUtil dbUtil;

    public EditPostServlet() {
        dbUtil = new DBUtil();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        Long postId = Long.parseLong(req.getParameter("postId"));

        Post post = dbUtil.getPost(postId);
        req.setAttribute("post", post);

        req.getRequestDispatcher( "editPost.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        Long postId = Long.parseLong(req.getParameter("postId"));
        String title = req.getParameter("title");
        String content = req.getParameter("content");

        boolean isSucccessfullyEdited = dbUtil.editPost(postId, title, content);
        if (isSucccessfullyEdited) {
            resp.sendRedirect("/home?page=home");
        } else {
            resp.sendRedirect("/editPost?postId="+postId+"&error=1");
        }
    }
}
