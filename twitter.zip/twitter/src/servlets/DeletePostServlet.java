package servlets;

import classes.Post;
import utils.DBUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/deletePost")
public class DeletePostServlet extends HttpServlet {

    DBUtil dbUtil;

    public DeletePostServlet() {
        dbUtil = new DBUtil();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        Long postId = Long.parseLong(req.getParameter("postId"));

        boolean isSucccessfullyDeleted = dbUtil.deletePost(postId);
        if (isSucccessfullyDeleted) {
            resp.sendRedirect("/home?page=home");
        } else {
            resp.sendRedirect("/home?page=home&error=2");
        }
    }
}
