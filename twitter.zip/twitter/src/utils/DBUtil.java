package utils;

import classes.Comment;
import classes.Post;
import classes.User;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DBUtil {

    Connection connection;

    public DBUtil() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1/twitter?useUnicode=true&characterEncoding=UTF-8", "root", "root");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<Post> getAllPosts() {

        List<Post> posts = new ArrayList<>();

        try {

            Statement st = connection.createStatement();
            ResultSet resultSet = st.executeQuery("SELECT b.*, u.name as username " +
                    "FROM blog b " +
                    "LEFT JOIN user u " +
                    "ON b.user_id = u.id;");

            while (resultSet.next()) {
                Long id = resultSet.getLong("id");
                Long userId = resultSet.getLong("user_id");
                String username = resultSet.getString("username");
                String title = resultSet.getString("title");
                String content = resultSet.getString("content");
                Timestamp postDate = resultSet.getTimestamp("post_date");
                Integer active = resultSet.getInt("active");

                List<Comment> comments = this.getPostComments(id);

                Post user = new Post(id, userId, username, title, content, postDate, comments, active);
                posts.add(user);
            }

            st.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return posts;
    }

    public List<Comment> getPostComments(Long blogId_) {

        List<Comment> comments = new ArrayList<>();

        try {

            Statement st = connection.createStatement();
            ResultSet resultSet = st.executeQuery("SELECT c.*, u.name as username " +
                    "FROM comment c " +
                    "LEFT JOIN user u " +
                    "ON c.user_id = u.id " +
                    "WHERE c.blog_id = "+blogId_);

            while (resultSet.next()) {
                Long id = resultSet.getLong("id");
                Long userId = resultSet.getLong("user_id");
                String username = resultSet.getString("username");
                Long blogId = resultSet.getLong("blog_id");
                String content = resultSet.getString("content");
                Timestamp postDate = resultSet.getTimestamp("post_date");
                Integer active = resultSet.getInt("active");

                Comment comment = new Comment(id, userId, username, blogId, content, postDate, active);
                comments.add(comment);
            }

            st.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return comments;
    }

    public boolean addUser(String name, String email, String password) {

        try {

            Statement st = connection.createStatement();
            String query = "INSERT INTO user (id, name, email, password)" +
                    " VALUES (NULL, '"+name+"', '"+email+"', '"+password+"')";

            st.executeUpdate(query);
            st.close();

            return true;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    public boolean addComment(Long userId, Long blogId, String content) {

        try {

            Statement st = connection.createStatement();
            String query = "INSERT INTO comment (id, user_id, blog_id, content, post_date, active)" +
                    " VALUES (NULL, "+userId+", "+blogId+", '"+content+"', NOW(), 1)";

            st.executeUpdate(query);
            st.close();

            return true;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
//
//    public List<User> getUsers() {
//
//        List<User> users = new ArrayList<>();
//
//        try {
//
//            Statement st = connection.createStatement();
//            ResultSet resultSet = st.executeQuery("SELECT id, email, password, name, surname, age FROM user");
//
//            while (resultSet.next()) {
//                Long id = resultSet.getLong("id");
//                String email = resultSet.getString("email");
//                String password = resultSet.getString("password");
//                String name = resultSet.getString("name");
//                String surname = resultSet.getString("surname");
//                Integer age = resultSet.getInt("age");
//
//                User user = new User(id, email, password, name, surname, age);
//                users.add(user);
//            }
//
//            st.close();
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//        return users;
//    }
//
    public User getUserByEmailAndPassword(String _email, String _password) {

        User user = null;

        try {

            Statement st = connection.createStatement();
            String query = "SELECT * FROM user WHERE email = '" + _email + "' AND password = '" + _password + "'";
            ResultSet resultSet = st.executeQuery(query);

            while (resultSet.next()) {

                Long id = resultSet.getLong("id");
                String email = resultSet.getString("email");
                String password = resultSet.getString("password");
                String name = resultSet.getString("name");

                user = new User(id, email, password, name);
            }

            st.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return user;
    }

    public Post getPost(Long postId) {

        Post post = null;

        try {

            Statement st = connection.createStatement();
            String query = "SELECT * FROM blog WHERE id = " + postId;
            ResultSet resultSet = st.executeQuery(query);

            while (resultSet.next()) {

                Long id = resultSet.getLong("id");
                Long userId = resultSet.getLong("user_id");
                String title = resultSet.getString("title");
                String content = resultSet.getString("content");
                Timestamp postDate = resultSet.getTimestamp("post_date");
                Integer active = resultSet.getInt("active");

                post = new Post(id, userId, title, content, postDate, active);
            }

            st.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return post;
    }

    public boolean editPost(Long postId, String title, String content) {

        try {

            Statement st = connection.createStatement();
            String query = "UPDATE blog SET title = '"+title+"', content = '"+content+"' WHERE id = " + postId;

            st.executeUpdate(query);
            st.close();

            return true;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    public boolean deletePost(Long postId) {

        try {

            Statement st = connection.createStatement();
            String query = "DELETE FROM blog WHERE id = " + postId;

            st.executeUpdate(query);
            st.close();

            return true;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }



}
